package kresonja.aplikacija;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AdapterListe extends RecyclerView.Adapter<AdapterListe.Red> {

    private List<Ontologija> podaci;
    private List<Ontologija> podaciTemp;
    private final LayoutInflater mInflater;
    private ItemClickListener mClickListener;

    public AdapterListe(Context context) {
        this.mInflater = LayoutInflater.from(context);
        podaci = new ArrayList<>();
    }

    @Override
    public Red onCreateViewHolder(ViewGroup roditelj, int viewType) {
        podaciTemp = new ArrayList<>(podaci);
        View view = mInflater.inflate(R.layout.red_liste, roditelj, false);
        return new Red(view);
    }

    @Override
    public void onBindViewHolder(Red red, int position) {
        Ontologija o = podaci.get(position);
        red.autor.setText(o.getAutor());
        red.izdavac.setText(o.getIzdavac());
        red.naslov.setText(o.getNaslov());
        red.zanr.setText(o.getZanr());
        red.brojStranica.setText(o.getBrojStranica());
    }

    @Override
    public int getItemCount() {
        return podaci == null ? 0 : podaci.size();
    }

    public class Red extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final TextView autor;
        private final TextView izdavac;
        private final TextView naslov;
        private final TextView zanr;
        private final TextView brojStranica;

        Red(View itemView) {
            super(itemView);
            autor = itemView.findViewById(R.id.autor);
            izdavac = itemView.findViewById(R.id.izdavac);
            naslov = itemView.findViewById(R.id.naslov);
            zanr = itemView.findViewById(R.id.zanr);
            brojStranica = itemView.findViewById(R.id.brojStranica);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }

    public Ontologija getItem(int id) {
        return podaci.get(id);
    }

    public void setPodaci(List<Ontologija> itemList) {
        this.podaci = itemList;
    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }

}
